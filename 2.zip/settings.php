<?php

return [
    'app_info' => [
        'api_id' => '',
        'api_hash' => '',
    ],
    'logger' => [
        'logger' => 0,
    ],
    'print_update' => true,
];

